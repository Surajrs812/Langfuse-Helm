{{/*
Expand the name of the chart.
*/}}
{{- define "langflow.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "langflow.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "langflow.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "langflow.labels" -}}
helm.sh/chart: {{ include "langflow.chart" . }}
{{ include "langflow.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "langflow.selectorLabels" -}}
app.kubernetes.io/name: {{ include "langflow.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "langflow.serviceAccountName" -}}
{{- if .Values.langflow.serviceAccount.create }}
{{- default (include "langflow.fullname" .) .Values.langflow.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.langflow.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return PostgreSQL hostname
*/}}
{{- define "langflow.postgresql.hostname" -}}
{{- if .Values.postgresql.host }}
{{- .Values.postgresql.host }}
{{- else if .Values.postgresql.deploy }}
{{- printf "%s-postgresql" (include "langflow.fullname" .) -}}
{{- end }}
{{- end }}

{{/*
Get a value from either a direct value or a secret reference
*/}}
{{- define "langflow.getValueOrSecret" -}}
{{- if (and .value.secretKeyRef.name .value.secretKeyRef.key) -}}
{{- if .value.value -}}
{{- fail (printf ".value and .secretKeyRef are mutually exclusive for %s" .key) -}}
{{- end -}}
valueFrom:
  secretKeyRef:
    name: {{ .value.secretKeyRef.name }}
    key: {{ .value.secretKeyRef.key }}
{{- else if .value.value -}}
value: {{ .value.value | quote }}
{{- end -}}
{{- end -}}

{{/*
Get a required value from either a direct value or a secret reference
*/}}
{{- define "langflow.getRequiredValueOrSecret" -}}
{{- with (include "langflow.getValueOrSecret" .) -}}
{{ . }}
{{- else -}}
{{ fail (printf "no valid value or secretKeyRef provided for %s" .key) }}
{{- end -}}
{{- end -}}

{{/*
Database related environment variables
*/}}
{{- define "langflow.databaseEnv" -}}
- name: LANGFLOW_DATABASE_URL
{{- if .Values.postgresql.auth.existingSecret }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.postgresql.auth.existingSecret }}
      key: {{ required "postgresql.auth.secretKeys.userPasswordKey is required when using an existing secret" .Values.postgresql.auth.secretKeys.userPasswordKey }}
{{- else }}
  value: "postgresql://{{ .Values.postgresql.auth.username }}:{{ required "postgresql.auth.password is required" .Values.postgresql.auth.password }}@{{ include "langflow.postgresql.hostname" . }}:{{ .Values.postgresql.port }}/{{ .Values.postgresql.auth.database }}{{ if .Values.postgresql.auth.args }}?{{ .Values.postgresql.auth.args }}{{ end }}"
{{- end }}
- name: LANGFLOW_AUTO_LOGIN
  value: {{ .Values.langflow.autoLogin | quote }}
{{- end -}}

{{/*
Core Langflow server environment variables
*/}}
{{- define "langflow.serverEnv" -}}
- name: LANGFLOW_LOG_LEVEL
  value: {{ .Values.langflow.logging.level | quote }}
- name: LANGFLOW_WORKERS
  value: {{ .Values.langflow.workers | quote }}
- name: LANGFLOW_TIMEOUT
  value: {{ .Values.langflow.timeout | quote }}
- name: LANGFLOW_MAX_FILE_SIZE_UPLOAD
  value: {{ .Values.langflow.maxUploadSize | quote }}
{{- with (include "langflow.getValueOrSecret" (dict "key" "langflow.secretKey" "value" .Values.langflow.secretKey)) }}
- name: LANGFLOW_SECRET_KEY
  {{- . | nindent 2 }}
{{- end }}
{{- if and .Values.langflow.superuser.username .Values.langflow.superuser.password }}
- name: LANGFLOW_SUPERUSER
  value: {{ .Values.langflow.superuser.username | quote }}
- name: LANGFLOW_SUPERUSER_PASSWORD
{{- if .Values.langflow.superuser.secretKeyRef.name }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.langflow.superuser.secretKeyRef.name }}
      key: {{ .Values.langflow.superuser.secretKeyRef.key }}
{{- else }}
  value: {{ .Values.langflow.superuser.password | quote }}
{{- end }}
{{- end }}
- name: LANGFLOW_TELEMETRY_ENABLED
  value: {{ .Values.langflow.features.telemetryEnabled | quote }}
- name: LANGFLOW_NEW_COMPONENTS_DISABLED
  value: {{ not .Values.langflow.features.newComponents | quote }}
{{- end -}}

{{/*
Common environment variables for all deployments
*/}}
{{- define "langflow.commonEnv" -}}
{{ include "langflow.serverEnv" . }}
{{ include "langflow.databaseEnv" . }}
{{- end -}}
