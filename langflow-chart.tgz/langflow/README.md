# Langflow Helm Chart

[Langflow](https://langflow.org/) is an open-source, low-code platform for building AI pipelines and agents. It provides a visual builder for RAG, LLM chains, and agentic workflows.

## TL;DR

```bash
helm install langflow ./langflow \
  --set postgresql.auth.password=changeme \
  --set langflow.superuser.password=changeme
```

## Introduction

This Helm chart deploys Langflow on a Kubernetes cluster. It is modeled after the Langfuse chart and follows the same structural conventions. It includes:

- **API server** (`langflow-api`) — the main Langflow backend and UI.
- **Worker** (`langflow-worker`) — optional Celery worker for background tasks.
- **PostgreSQL** — bundled via Bitnami subchart (can be disabled for external DB).
- **Istio VirtualService** — for Ezua/EZAF gateway integration.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.x
- (Optional) Istio for VirtualService support

## Installing the Chart

```bash
helm dependency update ./langflow
helm install langflow ./langflow -f my-values.yaml
```

## Configuration

### Minimal production values

```yaml
langflow:
  superuser:
    username: admin
    password: <your-strong-password>
  secretKey:
    value: <openssl rand -hex 32>

postgresql:
  auth:
    password: <your-db-password>
```

### Using an external PostgreSQL database

```yaml
postgresql:
  deploy: false
  host: my-postgres.example.com
  port: 5432
  auth:
    username: langflow
    password: secret
    database: langflow
```

### Enabling the worker

```yaml
langflow:
  worker:
    enabled: true
    replicas: 2
```

### Enabling Ingress

```yaml
langflow:
  ingress:
    enabled: true
    className: nginx
    hosts:
      - host: langflow.example.com
        paths:
          - path: /
            pathType: ImplementationSpecific
    tls:
      enabled: true
      secretName: langflow-tls
```

### Enabling HPA

```yaml
langflow:
  api:
    hpa:
      enabled: true
      minReplicas: 2
      maxReplicas: 6
      targetCPUUtilizationPercentage: 70
```

## Parameters

### Global

| Parameter | Description | Default |
|-----------|-------------|---------|
| `nameOverride` | Override the chart name | `""` |
| `fullnameOverride` | Override the full release name | `""` |

### Langflow

| Parameter | Description | Default |
|-----------|-------------|---------|
| `langflow.logging.level` | Log level (DEBUG, INFO, WARNING, ERROR) | `INFO` |
| `langflow.workers` | Number of uvicorn workers | `1` |
| `langflow.timeout` | Request timeout in seconds | `300` |
| `langflow.maxUploadSize` | Max file upload size (MB) | `100` |
| `langflow.autoLogin` | Disable authentication (dev only) | `false` |
| `langflow.secretKey.value` | Secret key for signing tokens | `""` |
| `langflow.superuser.username` | Initial admin username | `admin` |
| `langflow.superuser.password` | Initial admin password | `""` |
| `langflow.replicas` | Default replica count | `1` |
| `langflow.resources` | Default resource limits/requests | see values.yaml |

### API

| Parameter | Description | Default |
|-----------|-------------|---------|
| `langflow.api.image.repository` | API container image | `langflowai/langflow` |
| `langflow.api.service.type` | Service type | `ClusterIP` |
| `langflow.api.service.port` | Service port | `7860` |
| `langflow.api.hpa.enabled` | Enable HPA | `false` |
| `langflow.api.vpa.enabled` | Enable VPA | `false` |

### Worker

| Parameter | Description | Default |
|-----------|-------------|---------|
| `langflow.worker.enabled` | Deploy separate worker pod | `false` |
| `langflow.worker.image.repository` | Worker container image | `langflowai/langflow-backend` |
| `langflow.worker.hpa.enabled` | Enable HPA for worker | `false` |

### PostgreSQL

| Parameter | Description | Default |
|-----------|-------------|---------|
| `postgresql.deploy` | Deploy bundled PostgreSQL | `true` |
| `postgresql.host` | External host (when deploy=false) | `""` |
| `postgresql.auth.username` | Database username | `langflow` |
| `postgresql.auth.password` | Database password | `langflow` |
| `postgresql.auth.database` | Database name | `langflow` |

## Upgrading

```bash
helm upgrade langflow ./langflow -f my-values.yaml
```
